# XTeam-Exercise-4
## To Do
- [ ] Finish GraphProcessor.java
- [ ] Finish GraphProcessorTest.java
- [ ] Add more tests to GraphTest.java (optional)
- [ ] Add more comments and readability to all classes
  - [ ] Find better algorithm for isAdjacent (optional)
- [ ] Everyone look over someone else's class to make sure it makes sense and works
### Submission
- [ ] Double Check Requirements
- [ ] Submit
- [ ] Download and run submission from Lab Linux station
